import Login from './components/login/Login.vue';

export const routes = [
    { path: '/login', component: Login}
];